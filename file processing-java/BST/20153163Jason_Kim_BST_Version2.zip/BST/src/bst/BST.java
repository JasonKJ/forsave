package bst;
//실행환경 JAVA ECLIPSE를 22-09를 통해 작성하였음
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

final class Main {
	public static void main(String args[]) {
		BST tree = new BST(); // BST트리를 생성.
		File file = new File("src/bst/BST-input.txt");//txt파일 읽기
		try (BufferedReader br = new BufferedReader(new FileReader(file))) { // 버퍼를 생성해서 파일을 읽어오고.
		    String line;
		    while ((line = br.readLine()) != null) { // txt파일로부터 내용이 없을떄까지 한줄씩 line에 저장.
		    	String[] command = new String[2]; // 2개짜리 배열인 command에 저장후
		    	command = line.split(" ");//split을 통해서 공백을 기준으로 저장함
		    	if(command[0].compareTo("i") == 0) { // i일경우인풋이기때문에 insertBST를 호출하고 아닐경우엔 deleteBST를 호출함.
		    		
		    		tree.insertBST(tree, Integer.parseInt(command[1]));
		    	}
		    	else {
		    		tree.deleteBST(tree.getRoot(), Integer.parseInt(command[1]));
		    	}
		    }
		} catch (IOException e) {
		    e.printStackTrace(); // Exception 처리
		}
	}
}
abstract interface INode { // Node 인터페이스 부분, interface를 통해 Node Class에 있어야 할 함수들을 정의.
	
	public int element(); 
	
	public int height();
	
	public Node left();
	
	public Node right();
	
	public boolean noNodes();

}

final class Node implements INode{ //Node 부분.
	int element;
	int height;
	Node left;
	Node right;
	public int element() {
		return this.element;
	}
	public int height() {
		return this.height;
	}
	public Node left() {
		return this.left;
	}
	public Node right() {
		return this.right;
	}
	public boolean noNodes() { // Node class의 noNodes는 Child가 없을 경우 true를 있을경우 false를 반환.
		if (this.left == null && this.right == null) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public int getHeight(Node root) { // subtree의 Height를 구하는 함수.
		int leftHeight = 0;
        int rightHeight = 0;

        if (root.left != null) {
            leftHeight = 1 + getHeight(root.left);
        }

        if (root.right != null) {
            rightHeight = 1 + getHeight(root.right);
        }

        if( leftHeight > rightHeight ) {
        	this.height = leftHeight;
        	return leftHeight;
        }
        else {
        	this.height = rightHeight;
        	return rightHeight;
        }
	}
	public Node(int element) {
		
		this.element = element;
	}
}

public class BST {
	Node root = null;
	
	public BST() { // 생성자
		this.root = null;
	}
	public Node getRoot() { //root반환하는 getter
		return this.root;
	}
	public int height(Node T) { // Node T 를 기준으로 subtree의 height를 반환하는 함수.
		if(T == null) {
			return 0;
		}
		else {
			int leftHeight = height(T.left());
			int rightHeight = height(T.right());
		
			if(leftHeight > rightHeight) {
				return leftHeight + 1;
			}
			else {
				return rightHeight + 1;
			}
		
    
		}	
	}
	
	public void insertBST(BST T, int insertKey) { //insert를 구현하는 함수.
		Node parents = null;
		Node now = T.getRoot(); // 현재 보고있는Node를 now로 정의.
		
		while(now!= null) {
			if(insertKey == now.element()) {
				System.out.println("i" + " "+ insertKey + " : The key already exists");//insert하려는 key가 존재하면 print후 return.
				return;
			}
			parents = now; // parents에 now를 저장하고 now를 한단계 내릴 준비를함.
			if(insertKey < now.element()) { // key가 현재 element보다 작으면 왼쪽child로 now를 이동.
				now = now.left();
			}
			else {
				now = now.right(); // 크면 오른쪽으로 이동.
			}
		}
		Node newNode = new Node(insertKey); // 넣을node를 생성하고.
		if(T.getRoot() == null) { // Root가 없는 null BST면 루트에 저장.
			this.root = newNode;
			this.inOrder(root);
		}
		else if(insertKey < parents.element()) { // 작으면 왼쪽 크면 오른쪽에 배치.
			parents.left = newNode;
			this.inOrder(root);
		}
		else {
			parents.right = newNode;
			this.inOrder(root);
		}
		System.out.println();
	}
	
	public void visit(Node T) { // visit을 통해 element를 출력.
		System.out.print(T.element() + " ");
	}
	
	public void inOrder(Node T) { // inorder순서에따라서 재귀적으로 element출력.
		if (T == null) {
			return;
		}
		inOrder(T.left());
		visit(T);
		inOrder(T.right());
	}
	
	public int noNodes(Node T) { // noNodes함수를 통해 서브트리의 child개수를 구함.
		int no = 0;
		if(T == null) {
			return 0;
		}
		no = no+1;
		no = noNodes(T.left());
		no = noNodes(T.right());
		return no;
	}
	
	public Node search(Node T, int searchKey) { // search함수를 통해 searchKey를 가진 node가 존재하는지를 검색.
		Node parents = null;
		Node now = T;
		while(now != null) {
			if(searchKey == now.element()) {
				return now;
			}
			parents = now;
			if(searchKey < now.element()) {
				now = now.left();
			}
			else {
				now = now.right();
			}
		}
		return null;
	}
	
	public Node getParents(Node T, int key) { // getParents를 통해 부모Node가 존재하는지를 검사 있으면 parents를 없으면 null을 return.
		Node parents = null;
		Node now = T;
		while(now != null) {
			if(key == now.element()) {
				return parents;
			}
			parents = now;
			if(key < now.element()) {
				now = now.left();
			}
			else {
				now = now.right();
			}
		}
		return null;
	}
	public Node minNode(Node T) { // subtree의 노드들중 가장 작은 node를 return.
		if(T.left() == null) {
			return T;
		}
		else {
			return minNode(T.left());
		}
	}
	public Node maxNode(Node T) { // subtree의 노드들중 가장 큰 node를 return.
		if(T.right() == null) {
			return T;
		}
		else {
			return maxNode(T.right());
		}
	}
	public void deleteBST(Node T, int deleteKey) { // 삭제하는 부분.
		Node parents = getParents(T, deleteKey);
		Node p = search(T, deleteKey);
		if(p == null) { //search함수를 통해 삭제하려는 Node가 없으면 print후 return.
			System.out.println("d " + deleteKey + " : The key does not exist");
			return;
		}
		if(parents == null && p.left() == null && p.right() == null) { // 삭제하려는 Node가 루트일경우 루트 삭제후 return.
			this.root = null;
			inOrder(root);
			return;
		}
		if(p.left() == null && p.right() == null) { // Child가 없는 경우.
			if(parents.left() == p) { // 삭제하려는노드가 부모노드의 좌측일경우.
				parents.left = null;
				inOrder(root);
				System.out.println();
				
			}
			else {
				parents.right = null; // 우측일경우.
				inOrder(root);
				System.out.println();
				
			}
		}
		else if(parents == null && ((p.left() == null && p.right() != null) || (p.left() != null && p.right() == null))) { // parents가 없고 p의 자식이 하나인경우.
			if(p.left() == null) {
				root = p.right();
				inOrder(root);
				System.out.println();
			}
			else {
				root = p.left();
				inOrder(root);
				System.out.println();
			}
		}
		else if(parents != null && (p.left() == null && p.right() != null) || (p.left() != null && p.right() == null)) { // parents가 있고 p의 자식이 하나인경우.
			if(p.left == null) { // 삭제하려는 노드의 우측child만있는경우.
				if(parents.left == p) {
					parents.left = p.right();
					inOrder(root);
					System.out.println();
					
				}
				else {
					parents.right = p.right();
					inOrder(root);
					System.out.println();
					
				}
				
			}
			else {		//삭제하려는 노드의 좌측child만있는경우.
				if(parents.left == p) {
					parents.left = p.left();
					inOrder(root);
					System.out.println();
					
				}
				else {
					parents.right = p.left();
					inOrder(root);
					System.out.println();
				
				}	
			}
		}
		else if(p.left() != null && p.right() != null) { // 삭제하려는 Node의 child가 좌우 다 있는경우.
			int flag = 0; // 0 = left 1 = right; // flag를 통해 좌인지 우인지를 판단하고.
			Node r = null;
			if(height(p.left()) > height(p.right())) { // p좌측의 높이가 우측의 높이보다 크면.
				flag = 0;
				r = maxNode(p.left()); //좌측에서 빼야하니 r을 좌측의 노드중 가장 큰 노드로 설정하기위해 maxNode호출.
			}
			if(height(p.left()) < height(p.right())) { // 우측의 높이가 크면
				
				flag = 1;
				r = minNode(p.right()); //우측에서 빼야하니 r 우측의 subtree중 가장 작은것을 호출하기위해 minNode호출.
			}
			if(height(p.left()) == height(p.right())) { // 좌측과 우측의subtree가 같으면
				if(noNodes(p.left()) >= noNodes(p.right())){ // noNodes를 호출해 개수를 비교해서 왼쪽 오른쪽을 판단함.
					
					r = maxNode(p.left());
					flag = 0;
				}
				else {
					
					r = minNode(p.right());
					flag = 1;
				}
			}
			
			
			if(flag == 0) { // flag가 0 == 좌측일 경우와 우측일경우 모두 p를 r로 대치함.
				
				deleteBST(p, r.element());
				p.element = r.element;
			}
			else {
				
				deleteBST(p, r.element());
				p.element = r.element;
			}
		}

	}		
}


